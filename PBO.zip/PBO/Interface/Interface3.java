package PBO.Interface;

public interface Interface3 extends Interface1, Interface2{
    public void cetak();
}
