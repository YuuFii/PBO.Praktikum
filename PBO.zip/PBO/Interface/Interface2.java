package PBO.Interface;

public interface Interface2 {
    public String cetakInt1(int x);
    public String cetakInt2(int x);
}
