package PBO.Enumeration;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE;
}
