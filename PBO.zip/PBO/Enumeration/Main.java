package PBO.Enumeration;

public class Main {
    public static void main(String[] args) {
        Coffee kopi = new Coffee(Size.SMALL);
        System.out.println(kopi.getPrice());
    }
}
