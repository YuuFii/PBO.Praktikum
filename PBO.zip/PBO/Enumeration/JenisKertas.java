package PBO.Enumeration;

public enum JenisKertas {
    HVS,
    FOLIO,
    BUFFALO,
    CARTON;
}
