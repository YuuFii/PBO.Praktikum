package PBO.InnerClass;

/*
* */

public class ClassC {
    public static void main(String[] args) {
        ClassA a = new ClassA();
        a.methodPadaA();
    }
}




//        ClassA.ClassB b = new ClassA().new ClassB();
//        b.methodPadaB();
