package PBO.Collection.Map;
import java.util.*;

public class MapExample2 {
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<Integer, String>();
        map.put(100, "Tari");
    }
}
