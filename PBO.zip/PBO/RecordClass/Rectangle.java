package PBO.RecordClass;

public record Rectangle(double length, double width) { }
