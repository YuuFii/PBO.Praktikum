package PBO.StudyCase.PetHouse;

public interface CetakInfo {
    public void cetakInfo();
}
